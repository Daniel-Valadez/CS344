Daniel Valadez, 5-9-22, CS344
To compile the program type "make". To remove smallsh, type "make clean".
