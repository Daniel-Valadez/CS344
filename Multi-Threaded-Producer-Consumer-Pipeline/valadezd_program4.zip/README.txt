Daniel Valadez, 5-15-22, CS344

In order to compile the code, type in "gcc -o line_processor --std=gnu99 -pthread *.c". The executable should
be run by typing "./line_processor" with any file redirections be handled by the shell.
